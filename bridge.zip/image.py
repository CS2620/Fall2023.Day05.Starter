from PIL import Image as ImageLibrary


class Image:
    def __init__(self, filename):
        print("Booting image")
        self.imageLibrary = ImageLibrary.open(filename)
        self.buffer = self.imageLibrary.load()
        self.width = self.imageLibrary.size[0]
        self.height = self.imageLibrary.size[1]

    def save(self, filename):
        self.imageLibrary.save(filename, "png")

    def convertToGrayscale(self):
        for y in range(self.height):
            for x in range(self.width):
              pixel = self.buffer[x,y]

              r = pixel[0]
              g = pixel[1]
              b = pixel[2]

              grayscale = (r,r,r)
              self.buffer[x,y] = grayscale

